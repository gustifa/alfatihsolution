--
-- PostgreSQL database dump
--

\restrict vvIgjhmH3vi9UkFGT3DazMtPmgAtcnMOwR4GXzlFzhFjOygBHZqC5HZNDkIpSXM

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_log (
    id bigint NOT NULL,
    log_name character varying(255),
    description text NOT NULL,
    subject_type character varying(255),
    subject_id bigint,
    event character varying(255),
    causer_type character varying(255),
    causer_id bigint,
    attribute_changes json,
    properties json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.activity_log OWNER TO postgres;

--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_log_id_seq OWNER TO postgres;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache OWNER TO postgres;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO postgres;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection character varying(255) NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: guru_staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guru_staff (
    id bigint NOT NULL,
    nama character varying(255) NOT NULL,
    nip character varying(255),
    jabatan character varying(255) NOT NULL,
    kategori character varying(255) DEFAULT 'Guru'::character varying NOT NULL,
    foto character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT guru_staff_kategori_check CHECK (((kategori)::text = ANY ((ARRAY['Guru'::character varying, 'Tenaga Kependidikan'::character varying])::text[])))
);


ALTER TABLE public.guru_staff OWNER TO postgres;

--
-- Name: guru_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guru_staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guru_staff_id_seq OWNER TO postgres;

--
-- Name: guru_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guru_staff_id_seq OWNED BY public.guru_staff.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: jurnal_pikets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jurnal_pikets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    tanggal date NOT NULL,
    cuaca character varying(255),
    kondisi_kbm text,
    kejadian_penting text,
    foto_lampiran character varying(255),
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT jurnal_pikets_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'diserahkan'::character varying, 'disetujui'::character varying])::text[])))
);


ALTER TABLE public.jurnal_pikets OWNER TO postgres;

--
-- Name: jurnal_pikets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jurnal_pikets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jurnal_pikets_id_seq OWNER TO postgres;

--
-- Name: jurnal_pikets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jurnal_pikets_id_seq OWNED BY public.jurnal_pikets.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO postgres;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO postgres;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name text NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id bigint NOT NULL,
    author_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    featured_image character varying(255),
    meta_title character varying(255),
    meta_description character varying(160),
    meta_keywords character varying(255),
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: presensis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.presensis (
    id bigint NOT NULL,
    siswa_id bigint NOT NULL,
    tanggal date NOT NULL,
    waktu_scan time(0) without time zone NOT NULL,
    status character varying(255) DEFAULT 'hadir'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    waktu_pulang time(0) without time zone,
    CONSTRAINT presensis_status_check CHECK (((status)::text = ANY ((ARRAY['hadir'::character varying, 'terlambat'::character varying, 'izin'::character varying, 'sakit'::character varying, 'alpa'::character varying])::text[])))
);


ALTER TABLE public.presensis OWNER TO postgres;

--
-- Name: presensis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.presensis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.presensis_id_seq OWNER TO postgres;

--
-- Name: presensis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.presensis_id_seq OWNED BY public.presensis.id;


--
-- Name: profil_sekolahs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profil_sekolahs (
    id bigint NOT NULL,
    sejarah_singkat text,
    visi text,
    misi text,
    foto_struktur_organisasi character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    nama_kepala_sekolah character varying(255),
    foto_kepala_sekolah character varying(255),
    sambutan_kepala_sekolah text,
    nama_sekolah character varying(255) DEFAULT 'SMK Negeri 1 Bukittinggi'::character varying NOT NULL,
    slogan character varying(255),
    telepon character varying(255),
    email character varying(255),
    alamat text,
    logo character varying(255),
    favicon character varying(255),
    jumlah_siswa integer DEFAULT 0 NOT NULL,
    jumlah_guru integer DEFAULT 0 NOT NULL,
    jumlah_rombel integer DEFAULT 0 NOT NULL,
    jumlah_program integer DEFAULT 0 NOT NULL,
    hero_title character varying(255) DEFAULT 'Mencetak Generasi Siap Kerja'::character varying NOT NULL,
    hero_deskripsi text,
    gambar_hero json,
    tautan_penting json
);


ALTER TABLE public.profil_sekolahs OWNER TO postgres;

--
-- Name: profil_sekolahs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.profil_sekolahs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profil_sekolahs_id_seq OWNER TO postgres;

--
-- Name: profil_sekolahs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.profil_sekolahs_id_seq OWNED BY public.profil_sekolahs.id;


--
-- Name: program_keahlians; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.program_keahlians (
    id bigint NOT NULL,
    nama_program character varying(255) NOT NULL,
    singkatan character varying(255),
    deskripsi text,
    icon character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.program_keahlians OWNER TO postgres;

--
-- Name: program_keahlians_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.program_keahlians_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.program_keahlians_id_seq OWNER TO postgres;

--
-- Name: program_keahlians_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.program_keahlians_id_seq OWNED BY public.program_keahlians.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sarana_prasaranas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sarana_prasaranas (
    id bigint NOT NULL,
    nama_fasilitas character varying(255) NOT NULL,
    jumlah integer DEFAULT 1 NOT NULL,
    kondisi character varying(255) DEFAULT 'Baik'::character varying NOT NULL,
    foto character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT sarana_prasaranas_kondisi_check CHECK (((kondisi)::text = ANY ((ARRAY['Baik'::character varying, 'Rusak Ringan'::character varying, 'Rusak Berat'::character varying])::text[])))
);


ALTER TABLE public.sarana_prasaranas OWNER TO postgres;

--
-- Name: sarana_prasaranas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sarana_prasaranas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sarana_prasaranas_id_seq OWNER TO postgres;

--
-- Name: sarana_prasaranas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sarana_prasaranas_id_seq OWNED BY public.sarana_prasaranas.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: siswas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.siswas (
    id bigint NOT NULL,
    nis character varying(255) NOT NULL,
    barcode_uid character varying(255),
    nama character varying(255) NOT NULL,
    kelas character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    face_descriptor text,
    foto_wajah character varying(255)
);


ALTER TABLE public.siswas OWNER TO postgres;

--
-- Name: siswas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.siswas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.siswas_id_seq OWNER TO postgres;

--
-- Name: siswas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.siswas_id_seq OWNED BY public.siswas.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: guru_staff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guru_staff ALTER COLUMN id SET DEFAULT nextval('public.guru_staff_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: jurnal_pikets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jurnal_pikets ALTER COLUMN id SET DEFAULT nextval('public.jurnal_pikets_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: presensis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensis ALTER COLUMN id SET DEFAULT nextval('public.presensis_id_seq'::regclass);


--
-- Name: profil_sekolahs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profil_sekolahs ALTER COLUMN id SET DEFAULT nextval('public.profil_sekolahs_id_seq'::regclass);


--
-- Name: program_keahlians id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.program_keahlians ALTER COLUMN id SET DEFAULT nextval('public.program_keahlians_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sarana_prasaranas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sarana_prasaranas ALTER COLUMN id SET DEFAULT nextval('public.sarana_prasaranas_id_seq'::regclass);


--
-- Name: siswas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.siswas ALTER COLUMN id SET DEFAULT nextval('public.siswas_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_log (id, log_name, description, subject_type, subject_id, event, causer_type, causer_id, attribute_changes, properties, created_at, updated_at) FROM stdin;
1	Manajemen Berita	created	App\\Models\\Post	1	created	App\\Models\\User	1	{"attributes":{"id":1,"author_id":1,"title":"Lomba Konten Kreatif & Media Sosial","slug":"lomba-konten-kreatif-media-sosial","content":"<p>Lomba Konten Kreatif &amp; Media Sosial<\\/p>","featured_image":null,"meta_title":null,"meta_description":null,"meta_keywords":null,"status":"published","published_at":null,"created_at":"2026-09-21T06:50:38.000000Z","updated_at":"2026-09-21T06:50:38.000000Z"}}	[]	2026-09-21 06:50:38	2026-09-21 06:50:38
2	Manajemen Berita	updated	App\\Models\\Post	1	updated	App\\Models\\User	1	{"attributes":{"status":"draft","updated_at":"2026-09-21T08:52:59.000000Z"},"old":{"status":"published","updated_at":"2026-09-21T06:50:38.000000Z"}}	[]	2026-09-21 08:52:59	2026-09-21 08:52:59
3	Manajemen Berita	updated	App\\Models\\Post	1	updated	App\\Models\\User	1	{"attributes":{"status":"published","published_at":"2026-09-21 15:53:28","updated_at":"2026-09-21T08:53:34.000000Z"},"old":{"status":"draft","published_at":null,"updated_at":"2026-09-21T08:52:59.000000Z"}}	[]	2026-09-21 08:53:34	2026-09-21 08:53:34
4	Manajemen Berita	updated	App\\Models\\Post	1	updated	App\\Models\\User	1	{"attributes":{"featured_image":"posts\\/thumbnails\\/01M31JR8Y4S3Y5EB49WKVJPJ6Y.png","updated_at":"2026-09-21T08:54:05.000000Z"},"old":{"featured_image":null,"updated_at":"2026-09-21T08:53:34.000000Z"}}	[]	2026-09-21 08:54:05	2026-09-21 08:54:05
5	Manajemen Berita	updated	App\\Models\\Post	1	updated	App\\Models\\User	1	{"attributes":{"featured_image":null,"updated_at":"2026-09-21T09:07:57.000000Z"},"old":{"featured_image":"posts\\/thumbnails\\/01M31JR8Y4S3Y5EB49WKVJPJ6Y.png","updated_at":"2026-09-21T08:54:05.000000Z"}}	[]	2026-09-21 09:07:57	2026-09-21 09:07:57
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache (key, value, expiration) FROM stdin;
laravel-cache-livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3:timer	i:1789967118;	1789967118
laravel-cache-livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3	i:3;	1789967118
laravel-cache-spatie.permission.cache	a:3:{s:5:"alias";a:4:{s:1:"a";s:2:"id";s:1:"b";s:4:"name";s:1:"c";s:10:"guard_name";s:1:"r";s:5:"roles";}s:11:"permissions";a:128:{i:0;a:4:{s:1:"a";i:1;s:1:"b";s:16:"view_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:1;a:4:{s:1:"a";i:2;s:1:"b";s:20:"view_any_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:2;a:4:{s:1:"a";i:3;s:1:"b";s:18:"create_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:3;a:4:{s:1:"a";i:4;s:1:"b";s:18:"update_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:4;a:4:{s:1:"a";i:5;s:1:"b";s:19:"restore_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:5;a:4:{s:1:"a";i:6;s:1:"b";s:23:"restore_any_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:6;a:4:{s:1:"a";i:7;s:1:"b";s:21:"replicate_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:7;a:4:{s:1:"a";i:8;s:1:"b";s:19:"reorder_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:8;a:4:{s:1:"a";i:9;s:1:"b";s:18:"delete_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:9;a:4:{s:1:"a";i:10;s:1:"b";s:22:"delete_any_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:10;a:4:{s:1:"a";i:11;s:1:"b";s:24:"force_delete_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:11;a:4:{s:1:"a";i:12;s:1:"b";s:28:"force_delete_any_guru::staff";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:12;a:4:{s:1:"a";i:13;s:1:"b";s:18:"view_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:13;a:4:{s:1:"a";i:14;s:1:"b";s:22:"view_any_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:14;a:4:{s:1:"a";i:15;s:1:"b";s:20:"create_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:15;a:4:{s:1:"a";i:16;s:1:"b";s:20:"update_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:16;a:4:{s:1:"a";i:17;s:1:"b";s:21:"restore_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:17;a:4:{s:1:"a";i:18;s:1:"b";s:25:"restore_any_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:18;a:4:{s:1:"a";i:19;s:1:"b";s:23:"replicate_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:19;a:4:{s:1:"a";i:20;s:1:"b";s:21:"reorder_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:20;a:4:{s:1:"a";i:21;s:1:"b";s:20:"delete_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:21;a:4:{s:1:"a";i:22;s:1:"b";s:24:"delete_any_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:22;a:4:{s:1:"a";i:23;s:1:"b";s:26:"force_delete_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:23;a:4:{s:1:"a";i:24;s:1:"b";s:30:"force_delete_any_jurnal::piket";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:24;a:4:{s:1:"a";i:25;s:1:"b";s:19:"view_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:25;a:4:{s:1:"a";i:26;s:1:"b";s:23:"view_any_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:26;a:4:{s:1:"a";i:27;s:1:"b";s:21:"create_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:27;a:4:{s:1:"a";i:28;s:1:"b";s:21:"update_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:28;a:4:{s:1:"a";i:29;s:1:"b";s:22:"restore_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:29;a:4:{s:1:"a";i:30;s:1:"b";s:26:"restore_any_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:30;a:4:{s:1:"a";i:31;s:1:"b";s:24:"replicate_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:31;a:4:{s:1:"a";i:32;s:1:"b";s:22:"reorder_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:32;a:4:{s:1:"a";i:33;s:1:"b";s:21:"delete_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:33;a:4:{s:1:"a";i:34;s:1:"b";s:25:"delete_any_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:34;a:4:{s:1:"a";i:35;s:1:"b";s:27:"force_delete_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:35;a:4:{s:1:"a";i:36;s:1:"b";s:31:"force_delete_any_log::aktivitas";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:36;a:4:{s:1:"a";i:37;s:1:"b";s:9:"view_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:37;a:4:{s:1:"a";i:38;s:1:"b";s:13:"view_any_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:38;a:4:{s:1:"a";i:39;s:1:"b";s:11:"create_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:39;a:4:{s:1:"a";i:40;s:1:"b";s:11:"update_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:40;a:4:{s:1:"a";i:41;s:1:"b";s:12:"restore_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:41;a:4:{s:1:"a";i:42;s:1:"b";s:16:"restore_any_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:42;a:4:{s:1:"a";i:43;s:1:"b";s:14:"replicate_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:43;a:4:{s:1:"a";i:44;s:1:"b";s:12:"reorder_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:44;a:4:{s:1:"a";i:45;s:1:"b";s:11:"delete_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:45;a:4:{s:1:"a";i:46;s:1:"b";s:15:"delete_any_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:46;a:4:{s:1:"a";i:47;s:1:"b";s:17:"force_delete_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:47;a:4:{s:1:"a";i:48;s:1:"b";s:21:"force_delete_any_post";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:48;a:4:{s:1:"a";i:49;s:1:"b";s:13:"view_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:49;a:4:{s:1:"a";i:50;s:1:"b";s:17:"view_any_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:50;a:4:{s:1:"a";i:51;s:1:"b";s:15:"create_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:51;a:4:{s:1:"a";i:52;s:1:"b";s:15:"update_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:52;a:4:{s:1:"a";i:53;s:1:"b";s:16:"restore_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:53;a:4:{s:1:"a";i:54;s:1:"b";s:20:"restore_any_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:54;a:4:{s:1:"a";i:55;s:1:"b";s:18:"replicate_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:55;a:4:{s:1:"a";i:56;s:1:"b";s:16:"reorder_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:56;a:4:{s:1:"a";i:57;s:1:"b";s:15:"delete_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:57;a:4:{s:1:"a";i:58;s:1:"b";s:19:"delete_any_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:58;a:4:{s:1:"a";i:59;s:1:"b";s:21:"force_delete_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:59;a:4:{s:1:"a";i:60;s:1:"b";s:25:"force_delete_any_presensi";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:60;a:4:{s:1:"a";i:61;s:1:"b";s:20:"view_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:61;a:4:{s:1:"a";i:62;s:1:"b";s:24:"view_any_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:62;a:4:{s:1:"a";i:63;s:1:"b";s:22:"create_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:63;a:4:{s:1:"a";i:64;s:1:"b";s:22:"update_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:64;a:4:{s:1:"a";i:65;s:1:"b";s:23:"restore_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:65;a:4:{s:1:"a";i:66;s:1:"b";s:27:"restore_any_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:66;a:4:{s:1:"a";i:67;s:1:"b";s:25:"replicate_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:67;a:4:{s:1:"a";i:68;s:1:"b";s:23:"reorder_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:68;a:4:{s:1:"a";i:69;s:1:"b";s:22:"delete_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:69;a:4:{s:1:"a";i:70;s:1:"b";s:26:"delete_any_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:70;a:4:{s:1:"a";i:71;s:1:"b";s:28:"force_delete_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:71;a:4:{s:1:"a";i:72;s:1:"b";s:32:"force_delete_any_profil::sekolah";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:72;a:4:{s:1:"a";i:73;s:1:"b";s:22:"view_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:73;a:4:{s:1:"a";i:74;s:1:"b";s:26:"view_any_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:74;a:4:{s:1:"a";i:75;s:1:"b";s:24:"create_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:75;a:4:{s:1:"a";i:76;s:1:"b";s:24:"update_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:76;a:4:{s:1:"a";i:77;s:1:"b";s:25:"restore_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:77;a:4:{s:1:"a";i:78;s:1:"b";s:29:"restore_any_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:78;a:4:{s:1:"a";i:79;s:1:"b";s:27:"replicate_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:79;a:4:{s:1:"a";i:80;s:1:"b";s:25:"reorder_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:80;a:4:{s:1:"a";i:81;s:1:"b";s:24:"delete_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:81;a:4:{s:1:"a";i:82;s:1:"b";s:28:"delete_any_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:82;a:4:{s:1:"a";i:83;s:1:"b";s:30:"force_delete_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:83;a:4:{s:1:"a";i:84;s:1:"b";s:34:"force_delete_any_program::keahlian";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:84;a:4:{s:1:"a";i:85;s:1:"b";s:9:"view_role";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:85;a:4:{s:1:"a";i:86;s:1:"b";s:13:"view_any_role";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:86;a:4:{s:1:"a";i:87;s:1:"b";s:11:"create_role";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:87;a:4:{s:1:"a";i:88;s:1:"b";s:11:"update_role";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:88;a:4:{s:1:"a";i:89;s:1:"b";s:11:"delete_role";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:89;a:4:{s:1:"a";i:90;s:1:"b";s:15:"delete_any_role";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:90;a:4:{s:1:"a";i:91;s:1:"b";s:22:"view_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:91;a:4:{s:1:"a";i:92;s:1:"b";s:26:"view_any_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:92;a:4:{s:1:"a";i:93;s:1:"b";s:24:"create_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:93;a:4:{s:1:"a";i:94;s:1:"b";s:24:"update_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:94;a:4:{s:1:"a";i:95;s:1:"b";s:25:"restore_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:95;a:4:{s:1:"a";i:96;s:1:"b";s:29:"restore_any_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:96;a:4:{s:1:"a";i:97;s:1:"b";s:27:"replicate_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:97;a:4:{s:1:"a";i:98;s:1:"b";s:25:"reorder_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:98;a:4:{s:1:"a";i:99;s:1:"b";s:24:"delete_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:99;a:4:{s:1:"a";i:100;s:1:"b";s:28:"delete_any_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:100;a:4:{s:1:"a";i:101;s:1:"b";s:30:"force_delete_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:101;a:4:{s:1:"a";i:102;s:1:"b";s:34:"force_delete_any_sarana::prasarana";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:102;a:4:{s:1:"a";i:103;s:1:"b";s:10:"view_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:103;a:4:{s:1:"a";i:104;s:1:"b";s:14:"view_any_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:104;a:4:{s:1:"a";i:105;s:1:"b";s:12:"create_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:105;a:4:{s:1:"a";i:106;s:1:"b";s:12:"update_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:106;a:4:{s:1:"a";i:107;s:1:"b";s:13:"restore_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:107;a:4:{s:1:"a";i:108;s:1:"b";s:17:"restore_any_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:108;a:4:{s:1:"a";i:109;s:1:"b";s:15:"replicate_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:109;a:4:{s:1:"a";i:110;s:1:"b";s:13:"reorder_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:110;a:4:{s:1:"a";i:111;s:1:"b";s:12:"delete_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:111;a:4:{s:1:"a";i:112;s:1:"b";s:16:"delete_any_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:112;a:4:{s:1:"a";i:113;s:1:"b";s:18:"force_delete_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:113;a:4:{s:1:"a";i:114;s:1:"b";s:22:"force_delete_any_siswa";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:114;a:4:{s:1:"a";i:115;s:1:"b";s:9:"view_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:115;a:4:{s:1:"a";i:116;s:1:"b";s:13:"view_any_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:116;a:4:{s:1:"a";i:117;s:1:"b";s:11:"create_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:117;a:4:{s:1:"a";i:118;s:1:"b";s:11:"update_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:118;a:4:{s:1:"a";i:119;s:1:"b";s:12:"restore_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:119;a:4:{s:1:"a";i:120;s:1:"b";s:16:"restore_any_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:120;a:4:{s:1:"a";i:121;s:1:"b";s:14:"replicate_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:121;a:4:{s:1:"a";i:122;s:1:"b";s:12:"reorder_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:122;a:4:{s:1:"a";i:123;s:1:"b";s:11:"delete_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:123;a:4:{s:1:"a";i:124;s:1:"b";s:15:"delete_any_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:124;a:4:{s:1:"a";i:125;s:1:"b";s:17:"force_delete_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:125;a:4:{s:1:"a";i:126;s:1:"b";s:21:"force_delete_any_user";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:126;a:4:{s:1:"a";i:127;s:1:"b";s:29:"widget_FrontendShortcutWidget";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}i:127;a:4:{s:1:"a";i:128;s:1:"b";s:29:"widget_DashboardStatsOverview";s:1:"c";s:3:"web";s:1:"r";a:1:{i:0;i:1;}}}s:5:"roles";a:1:{i:0;a:3:{s:1:"a";i:1;s:1:"b";s:11:"super_admin";s:1:"c";s:3:"web";}}}	1790053510
laravel-cache-user-is-online-1	b:1;	1789983264
laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer	i:1789981894;	1789981894
laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab	i:1;	1789981894
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: guru_staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guru_staff (id, nama, nip, jabatan, kategori, foto, created_at, updated_at) FROM stdin;
3	Gibran	\N	Guru	Tenaga Kependidikan	\N	2026-09-21 07:55:40	2026-09-21 07:55:40
1	Gustifa	242142	Ka. Proka	Guru	\N	2026-09-21 07:31:50	2026-09-21 09:13:32
2	Amel	242142676	Guru	Tenaga Kependidikan	\N	2026-09-21 07:54:50	2026-09-21 09:13:40
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: jurnal_pikets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jurnal_pikets (id, user_id, tanggal, cuaca, kondisi_kbm, kejadian_penting, foto_lampiran, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2026_09_18_081250_create_permission_tables	1
5	2026_09_18_082838_create_posts_table	1
6	2026_09_18_102050_create_jurnal_pikets_table	1
7	2026_09_18_141418_create_siswas_table	1
8	2026_09_18_141427_create_presensis_table	1
9	2026_09_18_142423_create_personal_access_tokens_table	1
10	2026_09_18_152931_add_face_data_to_siswas_table	1
11	2026_09_18_232028_add_waktu_pulang_to_presensis_table	1
12	2026_09_19_055646_create_profil_sekolahs_table	1
13	2026_09_19_055647_create_guru_staff_table	1
14	2026_09_19_055649_create_sarana_prasaranas_table	1
15	2026_09_19_063849_add_sambutan_to_profil_sekolahs_table	1
16	2026_09_19_091903_add_pengaturan_to_profil_sekolahs_table	1
17	2026_09_19_100846_add_statistik_to_profil_sekolahs_table	1
18	2026_09_19_101920_add_hero_to_profil_sekolahs_table	1
19	2026_09_19_101923_create_program_keahlians_table	1
20	2026_09_20_044407_add_gambar_hero_to_profil_sekolahs_table	1
21	2026_09_20_045055_ubah_gambar_hero_jadi_json_di_profil_sekolahs	1
22	2026_09_20_152117_add_tautan_penting_to_profil_sekolahs_table	1
23	2026_09_20_160847_create_activity_log_table	1
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	view_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
2	view_any_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
3	create_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
4	update_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
5	restore_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
6	restore_any_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
7	replicate_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
8	reorder_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
9	delete_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
10	delete_any_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
11	force_delete_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
12	force_delete_any_guru::staff	web	2026-09-21 05:05:02	2026-09-21 05:05:02
13	view_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
14	view_any_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
15	create_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
16	update_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
17	restore_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
18	restore_any_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
19	replicate_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
20	reorder_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
21	delete_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
22	delete_any_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
23	force_delete_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
24	force_delete_any_jurnal::piket	web	2026-09-21 05:05:02	2026-09-21 05:05:02
25	view_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
26	view_any_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
27	create_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
28	update_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
29	restore_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
30	restore_any_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
31	replicate_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
32	reorder_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
33	delete_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
34	delete_any_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
35	force_delete_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
36	force_delete_any_log::aktivitas	web	2026-09-21 05:05:02	2026-09-21 05:05:02
37	view_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
38	view_any_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
39	create_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
40	update_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
41	restore_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
42	restore_any_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
43	replicate_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
44	reorder_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
45	delete_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
46	delete_any_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
47	force_delete_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
48	force_delete_any_post	web	2026-09-21 05:05:02	2026-09-21 05:05:02
49	view_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
50	view_any_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
51	create_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
52	update_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
53	restore_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
54	restore_any_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
55	replicate_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
56	reorder_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
57	delete_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
58	delete_any_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
59	force_delete_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
60	force_delete_any_presensi	web	2026-09-21 05:05:02	2026-09-21 05:05:02
61	view_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
62	view_any_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
63	create_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
64	update_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
65	restore_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
66	restore_any_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
67	replicate_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
68	reorder_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
69	delete_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
70	delete_any_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
71	force_delete_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
72	force_delete_any_profil::sekolah	web	2026-09-21 05:05:02	2026-09-21 05:05:02
73	view_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
74	view_any_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
75	create_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
76	update_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
77	restore_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
78	restore_any_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
79	replicate_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
80	reorder_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
81	delete_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
82	delete_any_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
83	force_delete_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
84	force_delete_any_program::keahlian	web	2026-09-21 05:05:02	2026-09-21 05:05:02
85	view_role	web	2026-09-21 05:05:02	2026-09-21 05:05:02
86	view_any_role	web	2026-09-21 05:05:02	2026-09-21 05:05:02
87	create_role	web	2026-09-21 05:05:02	2026-09-21 05:05:02
88	update_role	web	2026-09-21 05:05:02	2026-09-21 05:05:02
89	delete_role	web	2026-09-21 05:05:02	2026-09-21 05:05:02
90	delete_any_role	web	2026-09-21 05:05:02	2026-09-21 05:05:02
91	view_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
92	view_any_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
93	create_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
94	update_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
95	restore_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
96	restore_any_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
97	replicate_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
98	reorder_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
99	delete_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
100	delete_any_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
101	force_delete_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
102	force_delete_any_sarana::prasarana	web	2026-09-21 05:05:02	2026-09-21 05:05:02
103	view_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
104	view_any_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
105	create_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
106	update_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
107	restore_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
108	restore_any_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
109	replicate_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
110	reorder_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
111	delete_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
112	delete_any_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
113	force_delete_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
114	force_delete_any_siswa	web	2026-09-21 05:05:02	2026-09-21 05:05:02
115	view_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
116	view_any_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
117	create_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
118	update_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
119	restore_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
120	restore_any_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
121	replicate_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
122	reorder_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
123	delete_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
124	delete_any_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
125	force_delete_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
126	force_delete_any_user	web	2026-09-21 05:05:02	2026-09-21 05:05:02
127	widget_FrontendShortcutWidget	web	2026-09-21 05:05:02	2026-09-21 05:05:02
128	widget_DashboardStatsOverview	web	2026-09-21 05:05:02	2026-09-21 05:05:02
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, author_id, title, slug, content, featured_image, meta_title, meta_description, meta_keywords, status, published_at, created_at, updated_at) FROM stdin;
1	1	Lomba Konten Kreatif & Media Sosial	lomba-konten-kreatif-media-sosial	<p>Lomba Konten Kreatif &amp; Media Sosial</p>	\N	\N	\N	\N	published	2026-09-21 15:53:28	2026-09-21 06:50:38	2026-09-21 09:07:57
\.


--
-- Data for Name: presensis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.presensis (id, siswa_id, tanggal, waktu_scan, status, created_at, updated_at, waktu_pulang) FROM stdin;
\.


--
-- Data for Name: profil_sekolahs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profil_sekolahs (id, sejarah_singkat, visi, misi, foto_struktur_organisasi, created_at, updated_at, nama_kepala_sekolah, foto_kepala_sekolah, sambutan_kepala_sekolah, nama_sekolah, slogan, telepon, email, alamat, logo, favicon, jumlah_siswa, jumlah_guru, jumlah_rombel, jumlah_program, hero_title, hero_deskripsi, gambar_hero, tautan_penting) FROM stdin;
2	<p>Sambutan</p>	<p>Sambutan</p>	<p>Sambutan</p>	\N	2026-09-21 06:38:33	2026-09-21 07:11:31	Nurli Hayati, S.Pd	profil/01M31CK583JK0WMZC20VN35GGD.jpg	<p><strong>Assalamu’alaikum warahmatullahi wabarakatuh,</strong></p><p><strong>Salam sejahtera dan salam bahagia untuk kita semua.</strong></p><p>Puji dan syukur kita panjatkan ke hadirat Allah SWT, Tuhan Yang Maha Esa, atas rahmat dan karunia-Nya sehingga situs web resmi <strong>SD Negeri 59 Payakumbuh</strong> ini dapat hadir sebagai sarana informasi, komunikasi, dan transparansi bagi seluruh warga sekolah, orang tua murid, serta masyarakat luas.</p><p>Pendidikan sekolah dasar merupakan pondasi paling krusial dalam pembentukan karakter, pola pikir, dan potensi anak. Di era yang bergerak dinamis ini, peran pendidik tidak hanya sebatas menyampaikan ilmu pengetahuan di dalam kelas, tetapi juga menuntun peserta didik agar siap menghadapi tantangan masa depan. Kita tidak hanya menyiapkan anak-anak untuk hari ini, melainkan membekali mereka dengan keterampilan abad ke-21—kemampuan berpikir kritis, kreativitas, kolaborasi, dan literasi digital yang bijak.</p><p>Sebagai lembaga pendidikan dasar yang berpandangan jauh ke depan, kami berkeyakinan bahwa pemanfaatan teknologi dan inovasi pembelajaran harus berjalan beriringan dengan penguatan nilai-nilai budi pekerti serta akar budaya lokal. SD Negeri 59 Payakumbuh berkomitmen menciptakan lingkungan belajar yang adaptif, inklusif, dan menyenangkan, tempat setiap anak dihargai keunikannya, ditumbuhkan rasa ingin tahunya, dan didorong untuk menjadi pemelajar sepanjang hayat.</p><p>Kehadiran situs web ini diharapkan menjadi jembatan komunikasi dan sinergi yang kian erat antara sekolah, orang tua, dan masyarakat. Mendidik generasi masa depan yang unggul, berkarakter, dan berdaya saing tentu membutuhkan kerja sama serta gotong royong dari kita semua.</p><p>Terima kasih atas kepercayaan, partisipasi, dan dukungan yang terus diberikan kepada SD Negeri 59 Payakumbuh. Mari bersama-sama kita dampingi putra-putri kita menyongsong masa depan dengan optimisme dan karya nyata.</p><p><strong>Wassalamu’alaikum warahmatullahi wabarakatuh.</strong></p>	SD Negeri 59 Payakumbuh	Sambutan	085274817886	\N	 Pakan Sinayan, Payakumbuh Barat, Payakumbuh City, West Sumatra 26224	pengaturan/01M31CA4EE6E52X60BGD2FVVSR.jpeg	pengaturan/01M31CA4EKACVN1FPEEP1933BS.jpeg	0	0	0	0	Menuntun Potensi, Mendidik dengan Hati dan Visi	Berkarakter, Inovatif, Menjangkau Masa Depan	["profil\\/01M31B6RVEEY7646TQ0Y6P0D8N.jpeg"]	[]
\.


--
-- Data for Name: program_keahlians; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.program_keahlians (id, nama_program, singkatan, deskripsi, icon, created_at, updated_at) FROM stdin;
1	Kelas Unggul	1 SD	Kelas Unggul	program/01M31KPG7HT4QF0N0Q6Z3X4YNM.png	2026-09-21 09:10:00	2026-09-21 09:10:35
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	1
23	1
24	1
25	1
26	1
27	1
28	1
29	1
30	1
31	1
32	1
33	1
34	1
35	1
36	1
37	1
38	1
39	1
40	1
41	1
42	1
43	1
44	1
45	1
46	1
47	1
48	1
49	1
50	1
51	1
52	1
53	1
54	1
55	1
56	1
57	1
58	1
59	1
60	1
61	1
62	1
63	1
64	1
65	1
66	1
67	1
68	1
69	1
70	1
71	1
72	1
73	1
74	1
75	1
76	1
77	1
78	1
79	1
80	1
81	1
82	1
83	1
84	1
85	1
86	1
87	1
88	1
89	1
90	1
91	1
92	1
93	1
94	1
95	1
96	1
97	1
98	1
99	1
100	1
101	1
102	1
103	1
104	1
105	1
106	1
107	1
108	1
109	1
110	1
111	1
112	1
113	1
114	1
115	1
116	1
117	1
118	1
119	1
120	1
121	1
122	1
123	1
124	1
125	1
126	1
127	1
128	1
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	super_admin	web	2026-09-21 05:03:42	2026-09-21 05:03:42
\.


--
-- Data for Name: sarana_prasaranas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sarana_prasaranas (id, nama_fasilitas, jumlah, kondisi, foto, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
DNBQnyyN1fdRnsVtQkx2YIeYtmDQ81N6vzwndw4q	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJCMDdmeHBMdlFROUdlcHFoc1o1SDJtbFFvSTVTTjZNWmliNkJHd0IxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwIiwicm91dGUiOm51bGx9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19	1789982952
9L8GOnUD002vao1WfhTa6PLZtHSGwbKev2LKxU0r	1	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	eyJfdG9rZW4iOiJCTUdOS1ZaNmhGVDdrdkRFcENxNkpmOGl5VkdEcUlIM1dSVmU1VEt4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwXC9hZG1pblwva2Vsb2xhLWJhY2t1cCIsInJvdXRlIjoiZmlsYW1lbnQuYWRtaW4ucGFnZXMua2Vsb2xhLWJhY2t1cCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sInVybCI6W10sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxLCJwYXNzd29yZF9oYXNoX3dlYiI6ImM4YWNkZTNkYjFiYzY3NTJmZjViZjFkZGI5MjlmYjQ2MThjNDcwYTczYzI3ZTFkYjU3OGVkYTBhNjE4ZmY1ODIiLCJmaWxhbWVudCI6W119	1789982964
\.


--
-- Data for Name: siswas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.siswas (id, nis, barcode_uid, nama, kelas, created_at, updated_at, face_descriptor, foto_wajah) FROM stdin;
1	3242423	\N	Gustifa	X TITL 1	2026-09-21 07:32:22	2026-09-21 07:32:22	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
1	fauzan	fauzangustifa@gmail.com	\N	$2y$12$bsdpr4McbAnQACqXjR9c8eOCo6VZFj/K9we4Gk09a88VkN2PGWRSm	\N	2026-09-21 05:03:41	2026-09-21 05:03:41
\.


--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 5, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: guru_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guru_staff_id_seq', 5, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: jurnal_pikets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jurnal_pikets_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 23, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 128, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, true);


--
-- Name: presensis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.presensis_id_seq', 1, false);


--
-- Name: profil_sekolahs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.profil_sekolahs_id_seq', 2, true);


--
-- Name: program_keahlians_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.program_keahlians_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Name: sarana_prasaranas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sarana_prasaranas_id_seq', 1, false);


--
-- Name: siswas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.siswas_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: guru_staff guru_staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guru_staff
    ADD CONSTRAINT guru_staff_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: jurnal_pikets jurnal_pikets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jurnal_pikets
    ADD CONSTRAINT jurnal_pikets_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_unique UNIQUE (slug);


--
-- Name: presensis presensis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensis
    ADD CONSTRAINT presensis_pkey PRIMARY KEY (id);


--
-- Name: profil_sekolahs profil_sekolahs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profil_sekolahs
    ADD CONSTRAINT profil_sekolahs_pkey PRIMARY KEY (id);


--
-- Name: program_keahlians program_keahlians_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.program_keahlians
    ADD CONSTRAINT program_keahlians_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sarana_prasaranas sarana_prasaranas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sarana_prasaranas
    ADD CONSTRAINT sarana_prasaranas_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: siswas siswas_barcode_uid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.siswas
    ADD CONSTRAINT siswas_barcode_uid_unique UNIQUE (barcode_uid);


--
-- Name: siswas siswas_nis_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.siswas
    ADD CONSTRAINT siswas_nis_unique UNIQUE (nis);


--
-- Name: siswas siswas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.siswas
    ADD CONSTRAINT siswas_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: activity_log_log_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_log_log_name_index ON public.activity_log USING btree (log_name);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: causer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX causer ON public.activity_log USING btree (causer_type, causer_id);


--
-- Name: failed_jobs_connection_queue_failed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX failed_jobs_connection_queue_failed_at_index ON public.failed_jobs USING btree (connection, queue, failed_at);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: personal_access_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_expires_at_index ON public.personal_access_tokens USING btree (expires_at);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: subject; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subject ON public.activity_log USING btree (subject_type, subject_id);


--
-- Name: jurnal_pikets jurnal_pikets_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jurnal_pikets
    ADD CONSTRAINT jurnal_pikets_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: posts posts_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: presensis presensis_siswa_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.presensis
    ADD CONSTRAINT presensis_siswa_id_foreign FOREIGN KEY (siswa_id) REFERENCES public.siswas(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict vvIgjhmH3vi9UkFGT3DazMtPmgAtcnMOwR4GXzlFzhFjOygBHZqC5HZNDkIpSXM

